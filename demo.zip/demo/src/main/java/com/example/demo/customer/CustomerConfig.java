package com.example.demo.customer;


import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.time.Month;

@Configuration
public class CustomerConfig {
    @Bean
    CommandLineRunner commandLineRunner(CustomerRepository repository ){
        return args -> {
            Customer customer=new Customer(2L,"istrongdiem" ,"sttcap1" ,"sttcap2" ,"sttcap3" ,"mst" ,"tencty" ,"diachi" ,"tieuchitrongdiem" ,"mahq" ,LocalDate.of(2020,Month.JANUARY,5) ,LocalDate.of(2020,Month.JANUARY,5) ,"tinhtrang" ,"linhvuc" ,"nganhnghekd" ,"tkvnaccs" ,"tkdaily" ,"boss" ,"bossid" ,"bossaddr" ,"chicucthuequanly" ,"doitacnuocngoai" ,"chuhangthuctetaivietnam" ,"chuhangthuctetainuocngoai" ,"dailylogisticstainuocngoai" ,"dailylogisticstaivietnam" ,"thongtinthunhapvaphantich" ,"congchucid" ,"congchucname" ,"mstdnsatnhap" ,"tendnsatnhap" ,"diachidnsatnhap" ,"mstdnchiatach" ,"tendnchiatach" ,"diachidnchiatach");
            repository.save(customer);
        };

    }
}
