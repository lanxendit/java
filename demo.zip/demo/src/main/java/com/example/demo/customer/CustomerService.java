package com.example.demo.customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class CustomerService {
    private final CustomerRepository customerRepository;

    @Autowired

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public List<Customer> getCustomers() {
        return customerRepository.findAll();
//        return List.of(new Customer(1L,"sstcap1",1,1,"matHangNhapKhau","mst","tenDoanhNghiep","nguoiDaiDienPhapLuat","cmtCCCD","diaChi",
//                "diaChiNguoiDaiDienPhapLuat","tinhTrang", LocalDate.of(2000, Month.APRIL,10),"doiTacNuocNgoai","chuHangThucTeTaiVN","chuHangThucTeTaiNuocNgoai",
//                "daiLyLogisticsTaiNuocNgoai","daiLyLogisticsTaiVN","thongTinThuThapPhanTich"));
    }

    public void addCustomer(Customer customer) {
        Optional<Customer> customerOptional = customerRepository.findCustomerByMst(customer.getMst());
        if (customerOptional.isPresent()) {
            throw new IllegalStateException("mst ton tai");
        }
        customerRepository.save(customer);
        //System.out.print(customer);
    }

    public void deleteCustomerById(long id) {
       boolean exists= customerRepository.existsById(id);
       if(!exists){throw new IllegalStateException("khong ton tai id can xoa" + id);}
       customerRepository.deleteById(id);
    }
@Transactional
    public void updateCustomer(Long id, String istrongdiem, String sttcap1, String sttcap2, String sttcap3, String mst, String tencty, String diachi, String tieuchitrongdiem, String mahq, LocalDate ngaythanhlap, LocalDate ngaythaydoi, String tinhtrang, String linhvuc, String nganhnghekd, String tkvnaccs, String tkdaily, String boss, String bossid, String bossaddr, String chicucthuequanly, String doitacnuocngoai, String chuhangthuctetaivietnam, String chuhangthuctetainuocngoai, String dailylogisticstainuocngoai, String dailylogisticstaivietnam, String thongtinthunhapvaphantich, String congchucid, String congchucname, String mstdnsatnhap, String tendnsatnhap, String diachidnsatnhap, String mstdnchiatach, String tendnchiatach, String diachidnchiatach) {
        Customer customer=customerRepository.findById(id).orElseThrow(()->new IllegalStateException("khong ton tai id can update" + id));
        if(istrongdiem!=null && istrongdiem.length()>0 && !Objects.equals(customer.getIstrongdiem(),istrongdiem))
            customer.setIstrongdiem((istrongdiem));
    if(sttcap1!=null && sttcap1.length()>0 && !Objects.equals(customer.getSttcap1(),sttcap1))
        customer.setSttcap1((sttcap1));
    if(sttcap2!=null && sttcap2.length()>0 && !Objects.equals(customer.getSttcap2(),sttcap2))
        customer.setSttcap2((sttcap2));
    if(sttcap3!=null && sttcap3.length()>0 && !Objects.equals(customer.getSttcap3(),sttcap3))
        customer.setSttcap3((sttcap3));
//            ,"mst"
    if(mst!=null && mst.length()>0 && !Objects.equals(customer.getMst(),mst)){
        Optional<Customer> customerOptional=customerRepository.findCustomerByMst(mst);
        if(customerOptional.isPresent()){throw new IllegalStateException("mst da ton tai" + mst);}
        customer.setMst(mst);
    }
//            ,"tencty"
    if(tencty!=null && tencty.length()>0 && !Objects.equals(customer.getTencty(),tencty)){
        customer.setTencty(tencty);
    }

//            ,"diachi"
    if(diachi!=null && diachi.length()>0 && !Objects.equals(customer.getDiachi(),diachi))
        customer.setDiachi(diachi);
//            ,"tieuchitrongdiem"
    if(tieuchitrongdiem!=null && tieuchitrongdiem.length()>0 && !Objects.equals(customer.getTieuchitrongdiem(),tieuchitrongdiem))
        customer.setTieuchitrongdiem(tieuchitrongdiem);
//            ,"mahq"
    if(mahq!=null && mahq.length()>0 && !Objects.equals(customer.getMahq(),mahq))
        customer.setMahq(mahq);
//            ,ngaythanhlap LocalDate.of(2020,Month.JANUARY,5)
    if(ngaythanhlap!=null && !Objects.equals(customer.getNgaythanhlap(),ngaythanhlap))
        customer.setNgaythanhlap(ngaythanhlap);
//            ,ngaythaydoi LocalDate.of(2020,Month.JANUARY,5)
    if(ngaythaydoi!=null && !Objects.equals(customer.getNgaythaydoi(),ngaythaydoi))
        customer.setNgaythaydoi(ngaythaydoi);
//            ,"tinhtrang"
    if(tinhtrang!=null && tinhtrang.length()>0 && !Objects.equals(customer.getTinhtrang(),tinhtrang))
        customer.setTinhtrang(tinhtrang);
//            ,"linhvuc"
    if(linhvuc!=null && linhvuc.length()>0 && !Objects.equals(customer.getLinhvuc(),linhvuc))
        customer.setLinhvuc(linhvuc);
//            ,"nganhnghekd"
    if(nganhnghekd!=null && nganhnghekd.length()>0 && !Objects.equals(customer.getNganhnghekd(),nganhnghekd))
        customer.setNganhnghekd(nganhnghekd);
//            ,"tkvnaccs"
    if(tkvnaccs!=null && tkvnaccs.length()>0 && !Objects.equals(customer.getTkvnaccs(),tkvnaccs))
        customer.setTkvnaccs(tkvnaccs);
//            ,"tkdaily"
    if(tkdaily!=null && tkdaily.length()>0 && !Objects.equals(customer.getTkdaily(),tkdaily))
        customer.setTkdaily(tkdaily);
//            ,"boss"
    if(boss!=null && boss.length()>0 && !Objects.equals(customer.getBoss(),boss))
        customer.setBoss(boss);
//            ,"bossid"
    if(bossid!=null && bossid.length()>0 && !Objects.equals(customer.getBossid(),bossid))
        customer.setBossid(bossid);
//            ,"bossaddr"
    if(bossaddr!=null && bossaddr.length()>0 && !Objects.equals(customer.getBossaddr(),bossaddr))
        customer.setBossaddr(bossaddr);
//            ,"chicucthuequanly"
    if(chicucthuequanly!=null && chicucthuequanly.length()>0 && !Objects.equals(customer.getChicucthuequanly(),chicucthuequanly))
        customer.setChicucthuequanly(chicucthuequanly);
//            ,"doitacnuocngoai"
    if(doitacnuocngoai!=null && doitacnuocngoai.length()>0 && !Objects.equals(customer.getDoitacnuocngoai(),doitacnuocngoai))
        customer.setDoitacnuocngoai(doitacnuocngoai);
//            ,"chuhangthuctetaivietnam"
    if(chuhangthuctetaivietnam!=null && chuhangthuctetaivietnam.length()>0 && !Objects.equals(customer.getChuhangthuctetaivietnam(),chuhangthuctetaivietnam))
        customer.setChuhangthuctetaivietnam(chuhangthuctetaivietnam);
//            ,"chuhangthuctetainuocngoai"
    if(chuhangthuctetainuocngoai!=null && chuhangthuctetainuocngoai.length()>0 && !Objects.equals(customer.getChuhangthuctetainuocngoai(),chuhangthuctetainuocngoai))
        customer.setChuhangthuctetainuocngoai(chuhangthuctetainuocngoai);
//            ,"dailylogisticstainuocngoai"
    if(dailylogisticstainuocngoai!=null && dailylogisticstainuocngoai.length()>0 && !Objects.equals(customer.getDailylogisticstainuocngoai(),dailylogisticstainuocngoai))
        customer.setDailylogisticstainuocngoai(dailylogisticstainuocngoai);
//            ,"dailylogisticstaivietnam"
    if(dailylogisticstaivietnam!=null && dailylogisticstaivietnam.length()>0 && !Objects.equals(customer.getDailylogisticstaivietnam(),dailylogisticstaivietnam))
        customer.setDailylogisticstaivietnam(dailylogisticstaivietnam);
//            ,"thongtinthunhapvaphantich"
    if(thongtinthunhapvaphantich!=null && thongtinthunhapvaphantich.length()>0 && !Objects.equals(customer.getThongtinthunhapvaphantich(),thongtinthunhapvaphantich))
        customer.setThongtinthunhapvaphantich(thongtinthunhapvaphantich);
//            ,"congchucid"
    if(congchucid!=null && congchucid.length()>0 && !Objects.equals(customer.getCongchucid(),congchucid))
        customer.setCongchucid(congchucid);
//            ,"congchucname"
    if(congchucname!=null && congchucname.length()>0 && !Objects.equals(customer.getCongchucname(),congchucname))
        customer.setCongchucname(congchucname);
//            ,"mstdnsatnhap"
    if(mstdnsatnhap!=null && mstdnsatnhap.length()>0 && !Objects.equals(customer.getMstdnsatnhap(),mstdnsatnhap))
        customer.setMstdnsatnhap(mstdnsatnhap);
//            ,"tendnsatnhap"
    if(tendnsatnhap!=null && tendnsatnhap.length()>0 && !Objects.equals(customer.getTendnsatnhap(),tendnsatnhap))
        customer.setTendnsatnhap(tendnsatnhap);
//            ,"diachidnsatnhap"
    if(diachidnsatnhap!=null && diachidnsatnhap.length()>0 && !Objects.equals(customer.getDiachidnsatnhap(),diachidnsatnhap))
        customer.setDiachidnsatnhap(mahq);
//            ,"mstdnchiatach"
    if(mstdnchiatach!=null && mstdnchiatach.length()>0 && !Objects.equals(customer.getMstdnchiatach(),mstdnchiatach))
        customer.setMstdnchiatach(mstdnchiatach);
//            ,"tendnchiatach"
    if(tendnchiatach!=null && tendnchiatach.length()>0 && !Objects.equals(customer.getTendnchiatach(),tendnchiatach))
        customer.setTendnchiatach(tendnchiatach);
//            ,"diachidnchiatach"
    if(diachidnchiatach!=null && diachidnchiatach.length()>0 && !Objects.equals(customer.getDiachidnchiatach(),diachidnchiatach))
        customer.setDiachidnchiatach(diachidnchiatach);

    }
}
