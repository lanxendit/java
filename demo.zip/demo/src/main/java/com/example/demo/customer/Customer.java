package com.example.demo.customer;

import javax.persistence.*;
import java.time.LocalDate;
@Entity
@Table
public class Customer {
    @Id
    @SequenceGenerator(
            name="customer_sequence",
            sequenceName = "customer_sequence",
            allocationSize=1

    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator="customer_sequence"
    )
    private Long id;
    private String istrongdiem;
    private String sttcap1;
    private String sttcap2;
    private String sttcap3;
    private String mst;
    private String tencty;
    private String diachi;
    private String tieuchitrongdiem;
    private String mahq;
    private LocalDate ngaythanhlap;
    private LocalDate ngaythaydoi;
    private String tinhtrang;
    private String linhvuc;
    private String nganhnghekd;
    private String tkvnaccs;
    private String tkdaily;
    private String boss;
    private String bossid;
    private String bossaddr;
    private String chicucthuequanly;
    private String doitacnuocngoai;
    private String chuhangthuctetaivietnam;
    private String chuhangthuctetainuocngoai;
    private String dailylogisticstainuocngoai;
    private String dailylogisticstaivietnam;
    private String thongtinthunhapvaphantich;
    private String congchucid;
    private String congchucname;
    private String mstdnsatnhap;
    private String tendnsatnhap;
    private String diachidnsatnhap;
    private String mstdnchiatach;
    private String tendnchiatach;
    private String diachidnchiatach;
    public Customer(){
        super();
    }

    public Customer(Long id, String istrongdiem, String sttcap1, String sttcap2, String sttcap3, String mst, String tencty, String diachi, String tieuchitrongdiem, String mahq, LocalDate ngaythanhlap, LocalDate ngaythaydoi, String tinhtrang, String linhvuc, String nganhnghekd, String tkvnaccs, String tkdaily, String boss, String bossid, String bossaddr, String chicucthuequanly, String doitacnuocngoai, String chuhangthuctetaivietnam, String chuhangthuctetainuocngoai, String dailylogisticstainuocngoai, String dailylogisticstaivietnam, String thongtinthunhapvaphantich, String congchucid, String congchucname, String mstdnsatnhap, String tendnsatnhap, String diachidnsatnhap, String mstdnchiatach, String tendnchiatach, String diachidnchiatach) {
        this.id = id;
        this.istrongdiem = istrongdiem;
        this.sttcap1 = sttcap1;
        this.sttcap2 = sttcap2;
        this.sttcap3 = sttcap3;
        this.mst = mst;
        this.tencty = tencty;
        this.diachi = diachi;
        this.tieuchitrongdiem = tieuchitrongdiem;
        this.mahq = mahq;
        this.ngaythanhlap = ngaythanhlap;
        this.ngaythaydoi = ngaythaydoi;
        this.tinhtrang = tinhtrang;
        this.linhvuc = linhvuc;
        this.nganhnghekd = nganhnghekd;
        this.tkvnaccs = tkvnaccs;
        this.tkdaily = tkdaily;
        this.boss = boss;
        this.bossid = bossid;
        this.bossaddr = bossaddr;
        this.chicucthuequanly = chicucthuequanly;
        this.doitacnuocngoai = doitacnuocngoai;
        this.chuhangthuctetaivietnam = chuhangthuctetaivietnam;
        this.chuhangthuctetainuocngoai = chuhangthuctetainuocngoai;
        this.dailylogisticstainuocngoai = dailylogisticstainuocngoai;
        this.dailylogisticstaivietnam = dailylogisticstaivietnam;
        this.thongtinthunhapvaphantich = thongtinthunhapvaphantich;
        this.congchucid = congchucid;
        this.congchucname = congchucname;
        this.mstdnsatnhap = mstdnsatnhap;
        this.tendnsatnhap = tendnsatnhap;
        this.diachidnsatnhap = diachidnsatnhap;
        this.mstdnchiatach = mstdnchiatach;
        this.tendnchiatach = tendnchiatach;
        this.diachidnchiatach = diachidnchiatach;
    }

    public Customer(String istrongdiem, String sttcap1, String sttcap2, String sttcap3, String mst, String tencty, String diachi, String tieuchitrongdiem, String mahq, LocalDate ngaythanhlap, LocalDate ngaythaydoi, String tinhtrang, String linhvuc, String nganhnghekd, String tkvnaccs, String tkdaily, String boss, String bossid, String bossaddr, String chicucthuequanly, String doitacnuocngoai, String chuhangthuctetaivietnam, String chuhangthuctetainuocngoai, String dailylogisticstainuocngoai, String dailylogisticstaivietnam, String thongtinthunhapvaphantich, String congchucid, String congchucname, String mstdnsatnhap, String tendnsatnhap, String diachidnsatnhap, String mstdnchiatach, String tendnchiatach, String diachidnchiatach) {
        this.istrongdiem = istrongdiem;
        this.sttcap1 = sttcap1;
        this.sttcap2 = sttcap2;
        this.sttcap3 = sttcap3;
        this.mst = mst;
        this.tencty = tencty;
        this.diachi = diachi;
        this.tieuchitrongdiem = tieuchitrongdiem;
        this.mahq = mahq;
        this.ngaythanhlap = ngaythanhlap;
        this.ngaythaydoi = ngaythaydoi;
        this.tinhtrang = tinhtrang;
        this.linhvuc = linhvuc;
        this.nganhnghekd = nganhnghekd;
        this.tkvnaccs = tkvnaccs;
        this.tkdaily = tkdaily;
        this.boss = boss;
        this.bossid = bossid;
        this.bossaddr = bossaddr;
        this.chicucthuequanly = chicucthuequanly;
        this.doitacnuocngoai = doitacnuocngoai;
        this.chuhangthuctetaivietnam = chuhangthuctetaivietnam;
        this.chuhangthuctetainuocngoai = chuhangthuctetainuocngoai;
        this.dailylogisticstainuocngoai = dailylogisticstainuocngoai;
        this.dailylogisticstaivietnam = dailylogisticstaivietnam;
        this.thongtinthunhapvaphantich = thongtinthunhapvaphantich;
        this.congchucid = congchucid;
        this.congchucname = congchucname;
        this.mstdnsatnhap = mstdnsatnhap;
        this.tendnsatnhap = tendnsatnhap;
        this.diachidnsatnhap = diachidnsatnhap;
        this.mstdnchiatach = mstdnchiatach;
        this.tendnchiatach = tendnchiatach;
        this.diachidnchiatach = diachidnchiatach;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIstrongdiem() {
        return istrongdiem;
    }

    public void setIstrongdiem(String istrongdiem) {
        this.istrongdiem = istrongdiem;
    }

    public String getSttcap1() {
        return sttcap1;
    }

    public void setSttcap1(String sttcap1) {
        this.sttcap1 = sttcap1;
    }

    public String getSttcap2() {
        return sttcap2;
    }

    public void setSttcap2(String sttcap2) {
        this.sttcap2 = sttcap2;
    }

    public String getSttcap3() {
        return sttcap3;
    }

    public void setSttcap3(String sttcap3) {
        this.sttcap3 = sttcap3;
    }

    public String getMst() {
        return mst;
    }

    public void setMst(String mst) {
        this.mst = mst;
    }

    public String getTencty() {
        return tencty;
    }

    public void setTencty(String tencty) {
        this.tencty = tencty;
    }

    public String getDiachi() {
        return diachi;
    }

    public void setDiachi(String diachi) {
        this.diachi = diachi;
    }

    public String getTieuchitrongdiem() {
        return tieuchitrongdiem;
    }

    public void setTieuchitrongdiem(String tieuchitrongdiem) {
        this.tieuchitrongdiem = tieuchitrongdiem;
    }

    public String getMahq() {
        return mahq;
    }

    public void setMahq(String mahq) {
        this.mahq = mahq;
    }

    public LocalDate getNgaythanhlap() {
        return ngaythanhlap;
    }

    public void setNgaythanhlap(LocalDate ngaythanhlap) {
        this.ngaythanhlap = ngaythanhlap;
    }

    public LocalDate getNgaythaydoi() {
        return ngaythaydoi;
    }

    public void setNgaythaydoi(LocalDate ngaythaydoi) {
        this.ngaythaydoi = ngaythaydoi;
    }

    public String getTinhtrang() {
        return tinhtrang;
    }

    public void setTinhtrang(String tinhtrang) {
        this.tinhtrang = tinhtrang;
    }

    public String getLinhvuc() {
        return linhvuc;
    }

    public void setLinhvuc(String linhvuc) {
        this.linhvuc = linhvuc;
    }

    public String getNganhnghekd() {
        return nganhnghekd;
    }

    public void setNganhnghekd(String nganhnghekd) {
        this.nganhnghekd = nganhnghekd;
    }

    public String getTkvnaccs() {
        return tkvnaccs;
    }

    public void setTkvnaccs(String tkvnaccs) {
        this.tkvnaccs = tkvnaccs;
    }

    public String getTkdaily() {
        return tkdaily;
    }

    public void setTkdaily(String tkdaily) {
        this.tkdaily = tkdaily;
    }

    public String getBoss() {
        return boss;
    }

    public void setBoss(String boss) {
        this.boss = boss;
    }

    public String getBossid() {
        return bossid;
    }

    public void setBossid(String bossid) {
        this.bossid = bossid;
    }

    public String getBossaddr() {
        return bossaddr;
    }

    public void setBossaddr(String bossaddr) {
        this.bossaddr = bossaddr;
    }

    public String getChicucthuequanly() {
        return chicucthuequanly;
    }

    public void setChicucthuequanly(String chicucthuequanly) {
        this.chicucthuequanly = chicucthuequanly;
    }

    public String getDoitacnuocngoai() {
        return doitacnuocngoai;
    }

    public void setDoitacnuocngoai(String doitacnuocngoai) {
        this.doitacnuocngoai = doitacnuocngoai;
    }

    public String getChuhangthuctetaivietnam() {
        return chuhangthuctetaivietnam;
    }

    public void setChuhangthuctetaivietnam(String chuhangthuctetaivietnam) {
        this.chuhangthuctetaivietnam = chuhangthuctetaivietnam;
    }

    public String getChuhangthuctetainuocngoai() {
        return chuhangthuctetainuocngoai;
    }

    public void setChuhangthuctetainuocngoai(String chuhangthuctetainuocngoai) {
        this.chuhangthuctetainuocngoai = chuhangthuctetainuocngoai;
    }

    public String getDailylogisticstainuocngoai() {
        return dailylogisticstainuocngoai;
    }

    public void setDailylogisticstainuocngoai(String dailylogisticstainuocngoai) {
        this.dailylogisticstainuocngoai = dailylogisticstainuocngoai;
    }

    public String getDailylogisticstaivietnam() {
        return dailylogisticstaivietnam;
    }

    public void setDailylogisticstaivietnam(String dailylogisticstaivietnam) {
        this.dailylogisticstaivietnam = dailylogisticstaivietnam;
    }

    public String getThongtinthunhapvaphantich() {
        return thongtinthunhapvaphantich;
    }

    public void setThongtinthunhapvaphantich(String thongtinthunhapvaphantich) {
        this.thongtinthunhapvaphantich = thongtinthunhapvaphantich;
    }

    public String getCongchucid() {
        return congchucid;
    }

    public void setCongchucid(String congchucid) {
        this.congchucid = congchucid;
    }

    public String getCongchucname() {
        return congchucname;
    }

    public void setCongchucname(String congchucname) {
        this.congchucname = congchucname;
    }

    public String getMstdnsatnhap() {
        return mstdnsatnhap;
    }

    public void setMstdnsatnhap(String mstdnsatnhap) {
        this.mstdnsatnhap = mstdnsatnhap;
    }

    public String getTendnsatnhap() {
        return tendnsatnhap;
    }

    public void setTendnsatnhap(String tendnsatnhap) {
        this.tendnsatnhap = tendnsatnhap;
    }

    public String getDiachidnsatnhap() {
        return diachidnsatnhap;
    }

    public void setDiachidnsatnhap(String diachidnsatnhap) {
        this.diachidnsatnhap = diachidnsatnhap;
    }

    public String getMstdnchiatach() {
        return mstdnchiatach;
    }

    public void setMstdnchiatach(String mstdnchiatach) {
        this.mstdnchiatach = mstdnchiatach;
    }

    public String getTendnchiatach() {
        return tendnchiatach;
    }

    public void setTendnchiatach(String tendnchiatach) {
        this.tendnchiatach = tendnchiatach;
    }

    public String getDiachidnchiatach() {
        return diachidnchiatach;
    }

    public void setDiachidnchiatach(String diachidnchiatach) {
        this.diachidnchiatach = diachidnchiatach;
    }
}
