package com.example.demo.customer;

import com.example.demo.helper.ExcelHelper;
import com.example.demo.helper.ExcelService;
import com.example.demo.helper.ResponseMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping(path = "/customer")
public class CustomerController {
    private final CustomerService customerService;

    @Autowired
    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @GetMapping
    public List<Customer> getCustomers() {
        return customerService.getCustomers();
    }

    @PostMapping
    public void addCustomer(@RequestBody Customer customer) {
        customerService.addCustomer(customer);
    }

    @DeleteMapping("{id}")
    public void deleteCustomer(@PathVariable("id") long id) {
        customerService.deleteCustomerById(id);
    }

    @PutMapping("{id}")
    public void updateCustomer(
            @PathVariable("id") Long id, @RequestParam(required = false) String istrongdiem, @RequestParam(required = false) String sttcap1, @RequestParam(required = false) String sttcap2, @RequestParam(required = false) String sttcap3, @RequestParam(required = false) String mst, @RequestParam(required = false) String tencty, @RequestParam(required = false) String diachi, @RequestParam(required = false) String tieuchitrongdiem, @RequestParam(required = false) String mahq, @RequestParam(required = false) LocalDate ngaythanhlap, @RequestParam(required = false) LocalDate ngaythaydoi, @RequestParam(required = false) String tinhtrang, @RequestParam(required = false) String linhvuc, @RequestParam(required = false) String nganhnghekd, @RequestParam(required = false) String tkvnaccs, @RequestParam(required = false) String tkdaily, @RequestParam(required = false) String boss, @RequestParam(required = false) String bossid, @RequestParam(required = false) String bossaddr, @RequestParam(required = false) String chicucthuequanly, @RequestParam(required = false) String doitacnuocngoai, @RequestParam(required = false) String chuhangthuctetaivietnam, @RequestParam(required = false) String chuhangthuctetainuocngoai, @RequestParam(required = false) String dailylogisticstainuocngoai, @RequestParam(required = false) String dailylogisticstaivietnam, @RequestParam(required = false) String thongtinthunhapvaphantich, @RequestParam(required = false) String congchucid, @RequestParam(required = false) String congchucname, @RequestParam(required = false) String mstdnsatnhap, @RequestParam(required = false) String tendnsatnhap, @RequestParam(required = false) String diachidnsatnhap, @RequestParam(required = false) String mstdnchiatach, @RequestParam(required = false) String tendnchiatach, @RequestParam(required = false) String diachidnchiatach) {
        customerService.updateCustomer(id, istrongdiem, sttcap1, sttcap2, sttcap3, mst, tencty, diachi, tieuchitrongdiem, mahq, ngaythanhlap, ngaythaydoi, tinhtrang, linhvuc, nganhnghekd, tkvnaccs, tkdaily, boss, bossid, bossaddr, chicucthuequanly, doitacnuocngoai, chuhangthuctetaivietnam, chuhangthuctetainuocngoai, dailylogisticstainuocngoai, dailylogisticstaivietnam, thongtinthunhapvaphantich, congchucid, congchucname, mstdnsatnhap, tendnsatnhap, diachidnsatnhap, mstdnchiatach, tendnchiatach, diachidnchiatach);
    }
    @PostMapping("/upload")
    public ResponseEntity<ResponseMessage> uploadFile(@RequestParam("file") MultipartFile file) {
        String message = "";
        if (ExcelHelper.hasExcelFormat(file)) {
            try {
                ExcelService.save(file);
                message = "Uploaded the file successfully: " + file.getOriginalFilename();
                return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
            } catch (Exception e) {
                message = "Could not upload the file: " + file.getOriginalFilename() + "!";
                return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
            }
        }

        message = "Please upload an excel file!";
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage(message));
    }

}


